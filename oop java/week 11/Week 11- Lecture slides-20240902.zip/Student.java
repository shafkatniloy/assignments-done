package week11;


import java.util.Scanner;

public class Student {
	private String studentID;
	private String Name;
	
	//set the default values
	public Student(){
		
		
	}
	
	parameterised constructor
	public Student(){
		
		
	}
	// getters for name and ID



	//setters for name and ID


	
	
	// return proper string
	public String toString() {
		return "" ;
	}
	
}

